-- -------- < aula7exer2 > --------
--
--                    SCRIPT APAGA
--
-- Data Criacao ...........: 24/05/2023
-- Autor(es) ..............: Guilherme Soares Rocha
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula7exer2
--
-- PROJETO => 01 Base de Dados
--         => 09 tabelas
--        
-- 
-- Ultimas Alteracoes
--   24/05/223 => Criação do script
-- ---------------------------------------------------------

USE aula7exer2;

DROP TABLE TIPOPERFUMARIA;
DROP TABLE VENDIDO;
DROP TABLE VENDA;
DROP TABLE RECEITA;
DROP TABLE MEDICAMENTO;
DROP TABLE PERFUME;
DROP TABLE PRODUTO;
DROP TABLE TELEFONE;
DROP TABLE FABRICANTE;
DROP TABLE TIPOEMBALAGEM;